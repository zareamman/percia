<?php
namespace TMDBImporter\Core\Exceptions;

class ValidationException extends \Exception
{
    public function __construct(string $message = '', int $code = 0, \Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}